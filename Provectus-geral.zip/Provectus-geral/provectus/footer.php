 <footer>
        <center class="footer">
    	<i class="fa fa-facebook icones_footer"></i>
        <i class="fa fa-twitter icones_footer" ></i>
        <i class="fa fa-dribbble icones_footer"></i>
        </center>
    </footer>