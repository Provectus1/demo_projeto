<html>
<?php include 'cabecalho.php'?>
<body>

<section class="espaco_menu">
	
</section>
	<div id="content" class="grid_1 ponto_branco">.</div>
		<div id="content" class="grid_10">
			<img src="images/vovos_exato.jpg" id="foto_art">
			<h1 class="ponto_branco">.</h1>
					<div id="content" class="grid_2 ponto_branco">.</div>
				<h1 class="h1_art">COMO FAZER UM BOM ENSAIO FOTOGRÁFICO COM IDOSOS?</h1>


				<h2 class="h2_art">A fotografia de qualquer pessoa ou objeto tem suas nuances especiais e com um ensaio fotográficocom idosos não poderia.</h2>

				<h2 class="ponto_branco">.</h2>

				<p class="tamanho_conteudo">A atenção aos detalhes, a empatia e o jeito como trata esses modelos mais experientes são determinantes para o sucesso das fotos. Afinal de contas, esse público geralmente tem mais resistências que qualquer outro e até certa limitação para dar vida às fotos que o fotógrafo imagina.</p>

				<p class="tamanho_conteudo">Por isso, paciência, zelo e criatividade são indispensáveis na hora de fotografar pessoas idosas. Essas características vão contribuir não apenas para o sucesso das fotos como também para que as pessoas envolvidas curtam todo o ensaio fotográfico, o que é mais importante.</p>

				<p class="tamanho_conteudo">Logo, veja neste post algumas dicas essenciais para tornar o seu ensaio de terceira idade um sucesso. Confira esses conselhos indispensáveis e domine completamente esse ensaio pra lá de especial!</p>

				<h2 class="h1_art">NÃO SE ESQUEÇA DAS LIMITAÇÕES</h2>
				<p>O primeiro ponto é reconhecer as limitações dos modelos e respeitá-las durante toda a sessão de fotos com os idosos.</p>

				<p>Tenha em mente que atitudes simples, como sentar no chão ou ficar plenamente ereto, podem ser mais difíceis para as pessoas idosas do que parecem. A idade traz, junto com a experiência, limitações físicas e mentais que podem atrapalhar o ensaio fotográfico.</p>

				<p>Além disso, como o fotógrafo geralmente é mais novo não tem conhecimento dessas limitações. Mas lembre-se que as coisas simples para você podem não ser assim tão fáceis para os idosos.</p>

				<p>Portanto, antes de começar as capturas, converse com os modelos ou os clientes francamente. Procure descobrir suas limitações físicas como problemas de audição, dores na coluna, impossibilidade de se abaixar, visão comprometida, etc.</p>

				<p>Em seguida, crie um ensaio fotográfico com idosos que respeite todas essas particularidades e, mesmo assim, consiga extrair o máximo das cenas.</p>

				<p>São cuidados simples, mas que demonstram a sua preocupação como indivíduo para com seus clientes ou modelos. Não deixe essa dica passar em branco!</p>

				<p>Aliás, se fazer o briefing é uma tarefa costumeira em todos os serviços fotográficos por que com os idosos seria diferente? Pense nisso!</p>

				<p>Essa é uma dica que mistura um pouco do que vimos anteriormente, as limitações do idoso, com o zelo do fotógrafo pelas pessoas que serão registradas nas imagens.</p>

				<p>É comum que, durante o ensaio fotográfico, o profissional dê algumas instruções para melhorar o resultado final da fotografia. Alguns exemplos são: sugestões de poses, alinhamento de partes do corpo, indicação de ações para os modelos, etc.</p>

				<p>Contudo, quando falamos em fotografar idosos, é preciso criar uma forma especial de passar essas instruções. Esse cuidado precisa ser tomado não só pelas limitações físicas do modelo, mas também como forma de dar vida à sessão que você imaginou, como fotógrafo.</p>

				<p>Sendo assim, seja atencioso e didático nessas orientações. Repita o que disse quantas vezes forem necessárias e, de preferência, demonstre o que deseja que eles façam para facilitar o processo de comunicação.</p>

				<p>Ao agir assim você dá mais fluidez ao ensaio fotográfico, já que eles entenderão mais rápido o que você deseja. Da mesma forma, você evita que os idosos se sintam mal durante a sessão ou fiquem com um sentimento de que não são capazes de fazer as coisas. Fique esperto!</p>




		</div>

</body>
	<div id="content" class="grid_12">
		<?php include 'footer.php'?>

</html>