<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<meta name="viewport" content="width=device-width, initial-scale = 1.0, user-scalable = no">
	<title>Sharwadarma - Creative Onepage Template</title>
	<link rel="stylesheet" type="text/css" src="css/semantic/semantic.min.js">
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,600' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="css/normalize.css" media="screen">
	<link rel="stylesheet" href="css/grid.css" media="screen">
	<link rel="stylesheet" href="css/style.css" media="screen">
	<link rel="stylesheet" href="plugin/font-awesome/css/font-awesome.css" media="screen">
		<link rel="stylesheet" type="text/css" href="css/semantic/semantic.min.css">

	
</head>
<div class="menu">
		<div class="container clearfix">

			<div id="logo" class="grid_3">
				<img src="images/logo.png">
			</div>

			<div id="nav" class="grid_9 omega">
				<ul class="navigation">
					<li data-slide="1"> <a href="index.php"> Início</a></li>
					<li data-slide="2">Saúde</li>
					<li data-slide="3">Lazer</li>
					<li data-slide="4">Cuidadores</li>
					<li data-slide="5">Instituições</li>
					<li data-slide="8"><a href="###">Login</a></li>
				</ul>
			</div>

		</div>
	</div>