-- Gera��o de Modelo f�sico
-- Sql ANSI 2003 - brModelo.



CREATE TABLE idoso (
cidade varchar(100) NOT NULL,
estado varchar(2) NOT NULL,
id_ido int(3) PRIMARY KEY NOT NULL AUTO_INCREMENT,
cd_id_user int(3)
);

CREATE TABLE usuario (
img varchar(500),
id_user int(3) PRIMARY KEY NOT NULL AUTO_INCREMENT,
email varchar(100) NOT NULL,
tel varchar(15) NOT NULL,
nome varchar(50) NOT NULL,
senha varchar(50) NOT NULL,
cd_cod_tipuser int(1)
);

CREATE TABLE cuidador (
estado varchar(2) NOT NULL,
cidade varchar(100) NOT NULL,
texto varchar(700) NOT NULL,
valor varchar(100),
curric varchar(500),
id_cuid int(3) PRIMARY KEY NOT NULL AUTO_INCREMENT,
cd_id_user int(3),
FOREIGN KEY(cd_id_user) REFERENCES usuario (id_user)
);

CREATE TABLE tipo_user (
cod_tipuser int(1) PRIMARY KEY NOT NULL AUTO_INCREMENT,
tipo varchar(100) NOT NULL
);

CREATE TABLE categoria (
tipo varchar(100) NOT NULL,
cod_cat int(1) PRIMARY KEY NOT NULL AUTO_INCREMENT 
);

CREATE TABLE filtro (
cod_filtro int(1) PRIMARY KEY NOT NULL AUTO_INCREMENT,
tipo varchar(100) NOT NULL
);

CREATE TABLE artigo (
conteudo varchar(2500) NOT NULL,
titulo varchar(100) NOT NULL,
hora time NOT NULL,
autor varchar(50),
dat date NOT NULL,
cod_arti int(3) PRIMARY KEY NOT NULL AUTO_INCREMENT,
cd_cod_filtro int(1),
cd_cod_cat int(1),
FOREIGN KEY(cd_cod_filtro) REFERENCES filtro (cod_filtro),
FOREIGN KEY(cd_cod_cat) REFERENCES categoria (cod_cat)
);

CREATE TABLE imagem_art (
cd_cod_art int(3),
img varchar(500) NOT NULL,
cod_img_art int(3) PRIMARY KEY NOT NULL AUTO_INCREMENT,
FOREIGN KEY(cd_cod_art) REFERENCES artigo (cod_arti)
);

CREATE TABLE Instituicoes (
tel varchar(14) NOT NULL,
texto varchar(700) NOT NULL,
cidade varchar(100) NOT NULL,
nome varchar(100) NOT NULL,
rua varchar(150),
email varchar(100) NOT NULL,
estado varchar(2) NOT NULL,
num_ende int(4),
cod_inst int(3) PRIMARY KEY NOT NULL AUTO_INCREMENT,
img varchar(500)
);

CREATE TABLE like_art (
cd_id_user int(3),
cd_cod_arti int(3),
ativo int(1) NOT NULL,
FOREIGN KEY(cd_id_user) REFERENCES usuario (id_user),
FOREIGN KEY(cd_cod_arti) REFERENCES artigo (cod_arti)
);

CREATE TABLE maistarde_art (
cd_id_user int(3),
cd_cod_arti int(3),
ativo int(1) NOT NULL,
FOREIGN KEY(cd_id_user) REFERENCES usuario (id_user),
FOREIGN KEY(cd_cod_arti) REFERENCES artigo (cod_arti)
);

CREATE TABLE coment_cuid (
cd_id_ido int(3),
cd_id_cuid int(3),
comentario varchar(250) NOT NULL,
hora time NOT NULL,
dat date NOT NULL,
FOREIGN KEY(cd_id_ido) REFERENCES idoso (id_ido),
FOREIGN KEY(cd_id_cuid) REFERENCES cuidador (id_cuid)
);

CREATE TABLE nota_cuid (
cd_id_ido int(3),
cd_id_cuid int(3),
nota int(1) NOT NULL,
FOREIGN KEY(cd_id_ido) REFERENCES idoso (id_ido),
FOREIGN KEY(cd_id_cuid) REFERENCES cuidador (id_cuid)
);

CREATE TABLE maistarde_cuid (
cd_id_ido int(3),
cd_id_cuid int(3),
ativo int(1) NOT NULL,
FOREIGN KEY(cd_id_ido) REFERENCES idoso (id_ido),
FOREIGN KEY(cd_id_cuid) REFERENCES cuidador (id_cuid)
);

CREATE TABLE coment_inst (
cd_cod_inst int(3),
cd_cod_ido int(3),
comentario varchar(250) NOT NULL,
hora time NOT NULL,
dat date NOT NULL,
FOREIGN KEY(cd_cod_inst) REFERENCES Instituicoes (cod_inst),
FOREIGN KEY(cd_cod_ido) REFERENCES idoso (id_ido)
);

CREATE TABLE nota_inst (
cd_cod_inst int(3),
cd_cod_ido int(3),
nota int(1) NOT NULL,
FOREIGN KEY(cd_cod_inst) REFERENCES Instituicoes (cod_inst),
FOREIGN KEY(cd_cod_ido) REFERENCES idoso (id_ido)
);

CREATE TABLE maistarde_inst (
cd_cod_inst int(3),
cd_cod_ido int(3),
ativo int(1) NOT NULL,
FOREIGN KEY(cd_cod_inst) REFERENCES Instituicoes (cod_inst),
FOREIGN KEY(cd_cod_ido) REFERENCES idoso (id_ido)
);

CREATE TABLE coment_art (
cd_id_user int(3),
cd_cod_arti int(3),
comentario varchar(250) NOT NULL,
hora time NOT NULL,
dat date NOT NULL,
FOREIGN KEY(cd_id_user) REFERENCES usuario (id_user),
FOREIGN KEY(cd_cod_arti) REFERENCES artigo (cod_arti)
);

ALTER TABLE idoso ADD FOREIGN KEY(cd_id_user) REFERENCES usuario (id_user);
ALTER TABLE usuario ADD FOREIGN KEY(cd_cod_tipuser) REFERENCES tipo_user (cod_tipuser);
